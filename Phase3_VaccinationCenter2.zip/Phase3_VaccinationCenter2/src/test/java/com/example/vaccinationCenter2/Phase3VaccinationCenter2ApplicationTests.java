package com.example.vaccinationCenter2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Phase3VaccinationCenter2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
