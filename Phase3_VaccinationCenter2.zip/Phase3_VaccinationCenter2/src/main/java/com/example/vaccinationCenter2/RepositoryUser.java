package com.example.vaccinationCenter2;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface RepositoryUser extends JpaRepository<User, Integer> {

	String query = "select u from User u where u.userEmail=?1 and u.userPassword=?2";
	@Query(query)
	public User checkUser(String email, String password);
}
