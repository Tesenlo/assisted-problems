package com.example.vaccinationCenter2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServiceVacCenter {
	@Autowired
	RepositoryUser urepo;
	
	@Autowired
	RepositoryCitizen crepo;
	
	@Autowired
	RepositoryCenter vrepo;
	
	public User addUser(User user) {
		return urepo.save(user);
	}
	
	public User userLogin(String email, String password) {
		return urepo.checkUser(email, password);
	}
	
	public List<Citizen> getAllCitizen(){
		return crepo.findAll();
	}
	
	public List<VaccinationCenter> getAllCenter(){
		return vrepo.findAll();
	}
	
	public Citizen addCitizen(Citizen citizen) {
		return crepo.save(citizen);
	}

	public VaccinationCenter addCenter(VaccinationCenter center) {
		return vrepo.save(center);
	}
	
	public void deleteCenter(int id) {
		
		vrepo.deleteById(id);
	}
	
	public void deleteCitizen(int id) {
		crepo.deleteById(id);
	}
	
	public Citizen getCitizen(int id) {
		Citizen citizen = crepo.getById(id);
		return citizen;
	}
	
	public VaccinationCenter getCenter(int id) {
		VaccinationCenter center = vrepo.getById(id);
		return center;
	}
	
	public Citizen citizenInCenter(int id){
		Citizen citizen = crepo.citizenInCenter(id);
		return citizen;
	}
}
