package com.example.vaccinationCenter2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Phase3VaccinationCenter2Application {

	public static void main(String[] args) {
		SpringApplication.run(Phase3VaccinationCenter2Application.class, args);
	}

}
