package Assisted_Pracitce_Projects;

// Program in java by extending Thread Class
public class PracticeProject1 extends Thread{
	
	public void run() {
		System.out.println("concurrent thread started running");
	}
	
	public static void main(String[] args) {
		PracticeProject1 myThread = new PracticeProject1();
		myThread.start();
	}

}
