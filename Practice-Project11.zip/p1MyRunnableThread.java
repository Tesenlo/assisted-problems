package Assisted_Pracitce_Projects;

public class p1MyRunnableThread implements Runnable {
	public static int myCount = 0;
	public p1MyRunnableThread() {
		
	}
	public void run() {
		while(p1MyRunnableThread.myCount<=10) {
			System.out.println("ExplThread:"+(++p1MyRunnableThread.myCount));
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	}
	public static void main(String[] args) {
		System.out.println("Starting Main Thread...");
		
		p1MyRunnableThread mrt = new p1MyRunnableThread();
		Thread t = new Thread(mrt);
		t.start();
		
		while(p1MyRunnableThread.myCount<=10) {
			System.out.println("Main Thread:"+(++p1MyRunnableThread.myCount));
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("End of Main Thread...");
	}
}
