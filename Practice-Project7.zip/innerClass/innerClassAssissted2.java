// class inside method of another class

package innerClass;

public class innerClassAssissted2 {
	private String msg = "Inner Classes";
	
	void display() {                           //display() method
		class Inner{                           //class Inner inside  method display()
			void msg() {                       //msg() method inside class Inner
				System.out.println(msg);
			}
		}
		Inner I = new Inner();
		I.msg();	                           // calling msg() method from class Inner
	}                                          // display() method is closed here
	public static void main(String[] args) {
		innerClassAssissted2 ob = new innerClassAssissted2(); //created object ob of the main class
		ob.display();                                         //calling the display() method of the main class
	}
}
