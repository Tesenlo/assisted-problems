package practiceProjects3;
import java.util.Scanner;

public class LISmain {
	static void lis(int arr[], int n) {
	
		int LIS[] = new int[n];
		
		for(int i=0;i<n;i++) { //setting all values of LIS[] = 1
			LIS[i] = 1;
		}
		
		
		for(int i=1;i<n;i++) {
			for(int j=0;j<i;j++) {  //
				if(arr[i]>arr[j] && LIS[i]<LIS[j]+1) //comparing and changing values of LIS[]
					LIS[i] = LIS[j]+1;
			}
		}	
		
		int max=1;  //Finding the max from array LIS[]
		for(int i=0;i<n;i++)
			if (max<LIS[i])
				max = LIS[i];
		
		System.out.println("The Longest Integer Subsequence is: "+max);
		
		
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of elements: ");
		int n = sc.nextInt();
		
		int arr[] = new int[n];
		
		System.out.println("Enter the elements of the array:\n");
		for(int i=0;i<n;i++) {
		arr[i] = sc.nextInt();
		}
		lis(arr,n);
				
	}
}
