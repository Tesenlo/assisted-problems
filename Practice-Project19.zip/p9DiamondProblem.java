package Assisted_Pracitce_Projects;

interface First 
{  
    default void show() 
    { 
        System.out.println("Default First"); 
    } 
} 
interface Second 
{  
    default void show() 
    { 
        System.out.println("Default Second"); 
    } 
}  
public class p9DiamondProblem implements First, Second 
{  
    public void show() 
    {  
        First.super.show(); 
        Second.super.show(); 
    } 
    public static void main(String args[]) 
    { 
        p9DiamondProblem ob = new p9DiamondProblem(); 
        ob.show(); 
    } 
}

