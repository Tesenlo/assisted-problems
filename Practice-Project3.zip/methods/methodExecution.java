//1. demo method
package methods;

public class methodExecution {
	
	// method for multiplying two numbers
	public int multiplynumber(int a, int b) {
		int z = a*b;
		return z;
	}
	
	public static void main(String[] args) {
		methodExecution b = new methodExecution(); //created object b
		int ans = b.multiplynumber(10, 3);
		System.out.println("Multiplication is: "+ans);
	}
}
