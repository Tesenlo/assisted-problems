package pack1;

//3. using protected access specifier

public class proAccessSpecifier {
	protected void display() {
		System.out.println("This is protected access specifier");
	}
}
