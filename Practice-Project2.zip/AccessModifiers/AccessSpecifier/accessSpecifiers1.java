//1. default access specifier
package AccessSpecifier;

// Class is having default access
class defAccessSpecifier {
	
	//created a method called 'display'
	void display() {
		System.out.println("You are using default access specifier");
	}
}

public class accessSpecifiers1 {
	public static void main(String[] args) {
		//default
		System.out.println("Default Access Specifier");
		defAccessSpecifier obj = new defAccessSpecifier(); //created object called 'obj'
		obj.display(); //object calls method from different class
	}
}
