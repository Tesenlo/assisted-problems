//2. private access specifier
package AccessSpecifier;

//2. using private  access specifier

class priAccessSpecifier {
	private void display() {
		System.out.println("You are using private access specifier");
	}
}

public class accessSpecifier2 {
	public static void main(String[] args) {
		System.out.println("Private Access Specifier");
		priAccessSpecifier obj = new priAccessSpecifier();
		
		//trying to access private method of another class
		//obj.display(); // this will give error since display is a private method
	}

}
