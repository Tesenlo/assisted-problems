//3. protected access specifier
package AccessSpecifier;

import pack1.*;

public class accessSpecifier3 extends proAccessSpecifier {
	public static void main(String[] args) {
		accessSpecifier3 obj = new accessSpecifier3();
		obj.display(); //accessing protected method from different package in subclass
	}

}
