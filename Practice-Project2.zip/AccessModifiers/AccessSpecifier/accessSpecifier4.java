//4. Public Access Specifier

package AccessSpecifier;

import pack1.*;

public class accessSpecifier4 extends pubAccessSpecifier {
	public static void main(String[] args) {
		pubAccessSpecifier obj = new pubAccessSpecifier();
		obj.display();
	}

}
